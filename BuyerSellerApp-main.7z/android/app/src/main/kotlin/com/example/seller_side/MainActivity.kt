package com.example.seller_side

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
